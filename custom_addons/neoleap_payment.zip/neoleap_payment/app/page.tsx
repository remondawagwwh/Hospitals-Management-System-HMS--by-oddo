"use client"

import  from "../static/src/js/pos_neoleap"

export default function SyntheticV0PageForDeployment() {
  return < />
}