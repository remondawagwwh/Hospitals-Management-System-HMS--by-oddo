from . import payment_provider
from . import payment_transaction
from . import pos_payment_method
from . import hooks # <--- Added this line
